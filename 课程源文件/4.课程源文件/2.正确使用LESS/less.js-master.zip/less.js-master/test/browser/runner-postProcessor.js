describe("less.js postProcessor (deprecated)", function() {
    testLessEqualsInDocument();
});
