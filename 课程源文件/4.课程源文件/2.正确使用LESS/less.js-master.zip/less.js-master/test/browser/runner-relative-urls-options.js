var less = {logLevel: 4,
    errorReporting: "console"};
less.relativeUrls = true;
